require 'puppet/application/face_base'

class Puppet::Application::Storeconfigs < Puppet::Application::FaceBase
end
